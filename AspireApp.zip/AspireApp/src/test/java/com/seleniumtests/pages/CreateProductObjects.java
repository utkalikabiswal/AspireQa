package com.seleniumtests.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class CreateProductObjects 
{
	static WebDriver driver = null;
	
	By Inventory_btn=By.xpath("//a[@id='result_app_1']");
	
	By Click_Products = By.xpath("//button[@data-hotkey='3']");
	
	By Select_Products = By.xpath("//a[contains(text(),'Products')]");
	
	By Create_New = By.xpath("//button[@title='Create record']");
	
	
	By product_name = By.xpath("//input[@name='name']");
	
	public static By product_type = By.xpath("//select[@name='detailed_type']");
	
//	By unit_measure = By.xpath("//input[@class='o_input ui-autocomplete-input']");
//	
//	public static By purchase_UoM = By.xpath("//input[@class='o_input ui-autocomplete-input']");
	
	By internal_note = By.xpath("//div[@class='note-editable odoo-editor-editable']");
	
	By save_btn = By.xpath("//button[contains(text(),'Save')]");
	
	By update_quantity = By.xpath("//button[@name='action_update_quantity_on_hand']");
	
	By create_btn = By.xpath("//button[@class='btn btn-primary o_list_button_add']");
	
	By counted_quantity = By.xpath("//input[@name='inventory_quantity']");
	
	By save_quantity = By.xpath("//button[contains(text(),'Save')]");
	
	By product1 = By.xpath("//td[@class='o_data_cell o_field_cell o_list_many2one o_readonly_modifier o_required_modifier']");
	
	public CreateProductObjects(WebDriver driver) 	
	
	{
		this.driver = driver;
	}
	
	public void ClickInventoryButton()
	{
		driver.findElement(Inventory_btn).click();
	}
    
	public void ClickProducts() 
	{	
		driver.findElement(Click_Products).sendKeys(Keys.RETURN);
	}
	
	public void SelectProducts() 
	{
		driver.findElement(Select_Products).click();		
	}
	
	public void ClickCreateButton() 
	{
		driver.findElement(Create_New).click();	
	}
	
	public void SetProductName(String text)
	{
		driver.findElement(product_name).sendKeys(text);
	}
//	public void toClear()
//	{
//		WebElement toClear = (WebElement) driver.findElements(unit_measure);
//		toClear.sendKeys(Keys.CONTROL + "a");
//		toClear.sendKeys(Keys.DELETE);
//	}
	
//	public void SetUnitMeasure(String text)
//	{
//		driver.findElement(unit_measure).sendKeys(text);
//	}
	
	public void putInternalNote(String text)
	{
		driver.findElement(internal_note).sendKeys(text);

	}
	
	public void ClickSaveButton() 
	{
		driver.findElement(save_btn).click();	
	}
	
	public void UpdateQuantity() 
	{
		driver.findElement(update_quantity).click();	
	}
	
	public void ClickCreateBtn() 
	{
		driver.findElement(create_btn).click();	
	}
	
	public void countedQuantity(String text)
	{
		driver.findElement(counted_quantity).sendKeys(text);

	}
	
	public void SaveQuantity() 
	{
		driver.findElement(save_quantity).click();	
	}
	
	public String Product1() 
	{
		return driver.findElement(product1).getText();	
	}
}
