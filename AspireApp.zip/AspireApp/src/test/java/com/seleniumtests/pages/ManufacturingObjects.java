package com.seleniumtests.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ManufacturingObjects 
{
	WebDriver driver = null;
	
	By app_icon=By.xpath("//a[@class='dropdown-item o_menu_brand']");
	
	By manufacturing_button=By.xpath("//a[@class='oe_kanban_stock_picking_type_list oe_kanban_action oe_kanban_action_a']");
	
	By create_order=By.xpath("//button[@class='btn btn-primary o_list_button_add']");
	
	By product_name = By.xpath("//input[@class='o_input ui-autocomplete-input']");
	
	By manuf_save = By.xpath("//button[@class='btn btn-primary o_form_button_save']");
	
	By manuf_confirm = By.xpath("//button[@class='btn btn-primary']");
	
	By manuf_mark_done = By.xpath("//button[@class='btn btn-primary']");
	
	By product2 = By.xpath("1");
	
	By new_product_popup = By.xpath("//button[@class='btn btn-primary']");
	
	By immediate_production = By.xpath("//button[@class='btn btn-primary']");
	
	By Save_Inventory = By.xpath("//button[@class='btn btn-primary o_form_button_save']");
	
	By new_modal = By.xpath("//div[@class='modal-content']");
	
	public ManufacturingObjects(WebDriver driver) 	
	
	{
		this.driver = driver;
	}
	
	public void ClickAppIcon()
	{
		driver.findElement(app_icon).click();
	}
	
	public void ManufacturingButton()
	{
		driver.findElement(manufacturing_button).click();
	}
	
	public void CreateOrder()
	{
		driver.findElement(create_order).click();
	}

	public void ManufProductName(String text)
	{
		driver.findElement(product_name).sendKeys(text);
	}
	
	public void ManufSaveBtn()
	{
		driver.findElement(manuf_save).click();
	}
	
	public void ManufConfirmBtn()
	{
		driver.findElement(manuf_confirm).click();
	}
	
	public void ManufMarkDone()
	{
		driver.findElement(manuf_mark_done).click();
	}
	
	public String Product2() 
	{
		return driver.findElement(product2).getText();	
	}
	
	public void NewProductPopup() 
	{
		String handle = null;
		//driver.findElement(new_product_popup).click();	
		driver.switchTo().frame(0);
		driver.findElement(new_product_popup).click();
		driver.switchTo().defaultContent();
//		driver.switchTo().window(handle);
//	    driver.switchTo().frame(0);
//	    driver.findElement(new_product_popup).click();
	}
	
	public void ImmediateProduction()
	{
		driver.findElement(immediate_production).click();
	}
	
	public void SaveInventory()
	{
		driver.findElement(Save_Inventory).click();
	}
}
