package com.seleniumtests.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPageObjects 
{
	WebDriver driver = null;
	
	By email_id = By.xpath("//input[@id='login']");
	
	By pwd = By.xpath("//input[@id='password']");
	
	By Login_btn = By.xpath("//button[@type='submit']");
		
	
	public LoginPageObjects(WebDriver driver) 	
	
	{
		this.driver = driver;
	}
	
	public void setTextInEmailBox(String text)
	{
		driver.findElement(email_id).sendKeys(text);
	}
	
	public void setTextInPasswordBox(String text)
	{
		driver.findElement(pwd).sendKeys(text);
	}
	
	public void clickLoginButton()
	{
		driver.findElement(Login_btn).click();
	}
}
