package com.seleniumtests.Test;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.seleniumtests.pages.CreateProductObjects;
import com.seleniumtests.pages.LoginPageObjects;
import com.seleniumtests.pages.ManufacturingObjects;

public class AspireAppTest
{
	protected WebElement element = null;
	ExtentHtmlReporter htmlReporter;
	ExtentReports extent;
	
	WebDriver driver = null;
	
	@BeforeMethod
	@BeforeSuite
	public void setUp() {
		
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("ignoreProtectedModeSettings", true);
		
		htmlReporter = new ExtentHtmlReporter("extent.html");
		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);	
	}
	
	@BeforeTest
	public void setUpTest()
	{
		String projectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", projectPath+"/Drivers/chromedriver/chromedriver");
		driver=new ChromeDriver();
		
		driver.manage().window().maximize();
	}

	@Test
	public  void loginPageTest() 
	{
		
		LoginPageObjects loginpageobj = new LoginPageObjects(driver);
		
		driver.get("https://aspireapp.odoo.com/");
		//Enter Email and Password
		loginpageobj.setTextInEmailBox("user@aspireapp.com");
		loginpageobj.setTextInPasswordBox("@sp1r3app");
		
		// Login
		loginpageobj.clickLoginButton();		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		//Click on Inventory button
		CreateProductObjects createProductObject = new CreateProductObjects(driver);
		createProductObject.ClickInventoryButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				
		// Click on Products
		createProductObject.ClickProducts();
				
		//Select products from drop-down
		createProductObject.SelectProducts();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				
		//Click on Create Product
		createProductObject.ClickCreateButton();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Create Product
		createProductObject.SetProductName("Chocolate");

		
		createProductObject.putInternalNote("Creating a new Product");
		
		createProductObject.UpdateQuantity();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		
		createProductObject.ClickCreateBtn();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		createProductObject.countedQuantity("12");
		
		createProductObject.SaveQuantity();
		
		String ProductsProduct = createProductObject.Product1();
		
		
		
		// Click on Application icon
		ManufacturingObjects manufacturingObjects = new ManufacturingObjects(driver);
		
		manufacturingObjects.ClickAppIcon();
		
		//Navigate to Manufacturing Feature
		manufacturingObjects.ManufacturingButton();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);		
		
		//Create new Manufacturing order for created product
		manufacturingObjects.CreateOrder();
		
		//Enter Product name
		manufacturingObjects.ManufProductName("Chocolate");
		manufacturingObjects.ManufConfirmBtn();
		
		try {
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		
		manufacturingObjects.NewProductPopup();
		
		manufacturingObjects.ManufConfirmBtn();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);	
		
		manufacturingObjects.ManufMarkDone();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);	
		
		driver.switchTo().alert().accept();
		
		manufacturingObjects.ImmediateProduction();
		
		String ManufacturingProduct = manufacturingObjects.Product2();
		
		manufacturingObjects.SaveInventory();	
		
		
		if(ProductsProduct.equals(ManufacturingProduct))
			System.out.println();
		else
			System.out.println();
		
		
	}
	
	@AfterTest
	public void tearDownTest() {
		
		//close browser
				driver.close();By.xpath("//select[@name='detailed_type']");
				driver.quit();
				System.out.println("Test Completed Successfully");
		
	}
	@AfterMethod
	@AfterSuite
	public void tearDown() {
		 extent.flush();
	}

}
